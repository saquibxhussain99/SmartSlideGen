# prompt_templates.py

FINAL_CLAUDE_PROMPT = """
You are helping generate slides from a document.

TASK:
Output clean slide content in JSON format based on the text, images, and tables provided.

INSTRUCTIONS:
1. Each slide must have:
   - A short, clear "title"
   - At least 3 bullet points under "text" (each starting with •)
   - A "table" field only if there's a valid markdown table
   - An "image" field — assume figures or charts are shown if listed in IMAGES

2. Excel-style tables (comparison, ranking, trends) should be treated as images — set "table": [] and "text": "".

3. Do not generate slides with less than 3 bullet points.

4. Limit the number of bullet points per slide to 6.

5. Do not include redundant slides that repeat already mentioned facts.

6. Each bullet point should be a complete thought (e.g., "• The model achieved 94% accuracy on benchmark")

7. Output must be a valid JSON array (no text outside array).

CONTENT:
{text_content}

IMAGES: {image_paths}

TABLES:
{table_data}

OUTPUT FORMAT:
[
  {{
    "title": "Slide Title",
    "text": "• Bullet 1\\n• Bullet 2\\n• Bullet 3",
    "image": "",
    "table": []
  }},
  ...
]
"""
