import os
import json
import urllib.request
from dotenv import load_dotenv
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.enum.shapes import MSO_SHAPE
from llama_cloud_services import LlamaParse
from prompt_templates import ENHANCE_PRESENTATION_PROMPT


# === Load API Keys ===
load_dotenv()
LLAMA_API_KEY = os.getenv("LLAMACLOUD_API_KEY")
CLAUDE_API_KEY = os.getenv("ANTHROPIC_API_KEY")


assert LLAMA_API_KEY, "❌ LLAMACLOUD_API_KEY not found"
assert CLAUDE_API_KEY, "❌ ANTHROPIC_API_KEY not found"
print(f"🔑 Llama API Key Loaded: {LLAMA_API_KEY[:8]}...")
print(f"🔑 Claude API Key Loaded: {CLAUDE_API_KEY[:8]}...")


# === Claude API Call ===
def call_claude(prompt: str):
   url = "https://api.anthropic.com/v1/messages"
   headers = {
       "x-api-key": CLAUDE_API_KEY,
       "anthropic-version": "2023-06-01",
       "content-type": "application/json"
   }
   data = json.dumps({
       "model": "claude-3-5-sonnet-20241022",
       "max_tokens": 4096,
       "messages": [{"role": "user", "content": prompt}]
   }).encode("utf-8")


   req = urllib.request.Request(url, data=data, headers=headers, method="POST")
   with urllib.request.urlopen(req) as response:
       output = json.loads(response.read())
       return output['content'][0]['text']


# === Create Slide from JSON ===
def create_ppt(slide_data_list, image_paths, output_path, template_path):
   ppt = Presentation(template_path)
   blank_layout = ppt.slide_layouts[6]
   content_layout = ppt.slide_layouts[1]


   # Clear existing slides
   while ppt.slides:
       r_id = ppt.slides._sldIdLst[0].rId
       ppt.part.drop_rel(r_id)
       del ppt.slides._sldIdLst[0]


   for i, slide_data in enumerate(slide_data_list):
       title = slide_data.get("title", "").replace("(Image)", "").replace("(Table)", "").strip()
       text = slide_data.get("text", "")
       image = slide_data.get("image", "")
       table = slide_data.get("table", [])


       # === Table Slide ===
       if table:
           slide = ppt.slides.add_slide(blank_layout)
           left, top = Inches(0.5), Inches(1.5)
           rows, cols = len(table), len(table[0])
           width, height = Inches(9), Inches(4.5)
           table_shape = slide.shapes.add_table(rows, cols, left, top, width, height).table


           for r, row in enumerate(table):
               for c, cell in enumerate(row):
                   table_shape.cell(r, c).text = str(cell)
                   table_shape.cell(r, c).text_frame.paragraphs[0].font.size = Pt(12)


           # Add title manually
           textbox = slide.shapes.add_textbox(Inches(0.5), Inches(0.2), Inches(8), Inches(1))
           textbox.text = title
           textbox.text_frame.paragraphs[0].font.size = Pt(32)
           continue


       # === Content Slide ===
       slide = ppt.slides.add_slide(content_layout)
       slide.shapes.title.text = title


       # Shrink text box and move it down
       content = slide.placeholders[1]
       content.text = ""
       content.left = Inches(0.5)
       content.top = Inches(1.8)
       content.width = Inches(5.2)
       content.height = Inches(4.5)


       if text:
           tf = content.text_frame
           tf.clear()
           lines = [line.strip("•- ") for line in text.split("\n") if line.strip()]
           for i, line in enumerate(lines):
               if i == 0:
                   tf.text = f"• {line}"
               else:
                   p = tf.add_paragraph()
                   p.text = f"• {line}"
                   p.level = 0


       # Add image to the right
       if image and os.path.exists(image):
           pic_left = Inches(6)
           pic_top = Inches(2)
           pic_width = Inches(3)
           slide.shapes.add_picture(image, pic_left, pic_top, width=pic_width)


   # Thank You Slide
   final = ppt.slides.add_slide(ppt.slide_layouts[0])
   final.shapes.title.text = "Thank You!"


   ppt.save(output_path)
   print(f"✅ Presentation saved at: {output_path}")


# === Build ===
def build_presentation(llama_key, claude_key, docx_path, pptx_template, output_path):
   parser = LlamaParse(api_key=llama_key, language="en", verbose=True)
   result = parser.parse(docx_path)


   print("📄 Raw Llama output received...")
   pages = result.pages
   if not pages:
       print("⚠️ No pages found. Exiting.")
       return


   # === Images ===
   image_dir = "images"
   os.makedirs(image_dir, exist_ok=True)
   for f in os.listdir(image_dir):
       os.remove(os.path.join(image_dir, f))


   image_docs = result.get_image_documents(
       include_screenshot_images=True,
       include_object_images=True,
       image_download_dir=image_dir
   )
   images = sorted([
       os.path.join(image_dir, f) for f in os.listdir(image_dir)
       if f.lower().endswith((".png", ".jpg", ".jpeg"))
   ])


   slide_data = []
   for i, page in enumerate(pages):
       page_text = page.text
       tables = page.structuredData.get("tables", []) if page.structuredData else []
       image_path = images[i] if i < len(images) else None


       prompt = ENHANCE_PRESENTATION_PROMPT.format(
           text_content=page_text,
           image_paths=[image_path] if image_path else [],
           table_data=json.dumps(tables, indent=2)
       )


       print(f"📨 Sending prompt for page {i+1} to Claude...")
       response = call_claude(prompt)


       try:
           structured = json.loads(response)
           for slide in structured:
               slide["image"] = image_path
               slide_data.append(slide)
       except Exception as e:
           print(f"⚠️ Failed to parse Claude JSON for page {i+1}: {e}")


   create_ppt(slide_data, images, output_path, pptx_template)


# === Main ===
def main():
   input_doc = "document/doc.docx"
   pptx_template = "template/template.pptx"
   output_pptx = "output/output_presentation.pptx"
   build_presentation(LLAMA_API_KEY, CLAUDE_API_KEY, input_doc, pptx_template, output_pptx)


if __name__ == "__main__":
   main()
