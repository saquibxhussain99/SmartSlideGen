# prompt_templates.py

FINAL_CLAUDE_PROMPT = """
You are helping generate slides from a document.

Based on the given text, your task is to output slide content in structured JSON format.

INSTRUCTIONS:
1. Split content into multiple slides.
2. Each slide should have:
   - A clear and concise "title"
   - A bullet-style "text" field (each line starts with •)
   - An "image" field (just leave it blank "")
   - A "table" field (use a 2D array if applicable, else [])

3. If the slide has a chart or Excel-style table, represent it under "table" and set "text" as empty.

CONTENT:
{text_content}

IMAGES: {image_paths}

TABLES: {table_data}

Output in this JSON format:
[
  {{
    "title": "Slide Title",
    "text": "• Bullet 1\\n• Bullet 2",
    "image": "",
    "table": []
  }},
  ...
]
"""



ENRICH_PRESENTATION_PROMPT = """
You are an AI presentation assistant. Given the text content from a document page, generate slides in JSON format.

Format:
[
  {{
    "title": "Slide title",
    "text": "• Bullet 1\\n• Bullet 2\\n• Bullet 3",
    "image": "",  // leave blank
    "table": []   // only if it's a structured table
  }},
  ...
]

Rules:
1. Split into multiple slides if needed.
2. Always return bullets under "text" — never paragraphs.
3. If a table looks like a chart (e.g., Box Office vs. Legacy Impact), label the slide as a "chart" and include the table data.
4. Each slide should either have text or a table (or both, if small). But large tables must go on a dedicated slide.
5. DO NOT include "(Image)" or "(Table)" in the title or bullets.
6. Return clean, parsable JSON.

Document Content:
{text_content}

Tables:
{table_data}

Associated Image Paths:
{image_paths}
"""




GENERATE_SLIDE_CONTENT_TEMPLATE = """
You will be given a key topic, and a document portion, which provide detail about the key topic. Your task is to create slides based on the document portion. Follow these steps:

1. Identify the relevant section of the document between the given starting lines.
2. Analyze this section and create slides with titles and bullet points.

Guidelines:
- The number of slides can be as few as one and as many as 10, depending on the amount of non-repetitive information in the relevant section of the key topic.
- Present slides in the order that the information appears in the document.
- Each slide should have 4-6 concise bullet points, each containing a single key idea or fact.
- Use concise phrases or short sentences for bullet points, focusing on conveying key information clearly and succinctly.
- If information seems relevant to multiple topics, include it in the current topic's slides, as it appears first in the document.
- Avoid redundancy across slides within the same key topic.
- **Do not include additional commentary, explanations, or “Note:” sections. Provide only the slide titles and bullet points.**
- please do not add any additional comments or notes or train of thought. The slides should only include things about the movies

You will be given a document portion. Your task is to create slides from this.

Guidelines:
- Make 1 to 10 slides based on amount of content.
- Each slide should have 4-6 concise bullet points.
- Use short, clear, factual bullets — no explanations.
- Do not include comments or headings outside slide structure.

Output Format:
**paste slide title here**
paste point 1 here
paste point 2 here
paste point 3 here

Inputs:
Document portion:
'''
{{contentSegment}}
'''

Please return the slides in the above format only.

Inputs:
Key Topic: '''{{topic}}'''

Document portion:'''
{{contentSegment}}
'''

Please create slides based on the document portion, following the guidelines provided. Ensure that the slides comprehensively cover the key topic without unnecessary repetition.
**Output only the slide content** (titles + bullet points). **Do not add any extra notes or remarks**.
Please do not add any additional comments or notes or train of thought. The slides should only include things about the movies

"""